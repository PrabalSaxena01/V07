(function(){
  function boot(){
    var el=document.getElementById('tk-info');
    if(!el)return;
    el.textContent='pluginId='+V07.pluginId+' mode='+V07.mode+' features='+JSON.stringify(V07.features||{});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);
  else boot();
})();
