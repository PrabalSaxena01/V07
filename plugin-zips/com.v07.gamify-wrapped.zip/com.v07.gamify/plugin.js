// Gamify plugin — XP, levels, streaks, perfect days.
// Reads existing event categories via V07.* bridge (synchronous) and maintains
// its own per-day XP ledger in the 'gamify' event category.

(function () {
  // ─── Level curve: cumulative XP required to REACH level L ───────────────
  // xpForLevel(L) = 100 * L^1.5
  function xpForLevel(level) {
    return Math.floor(100 * Math.pow(Math.max(level, 0), 1.5));
  }

  function levelFromXp(xp) {
    var level = 1;
    while (xpForLevel(level) <= xp) level++;
    return Math.max(1, level - 1);
  }

  function progressFromXp(xp) {
    xp = Math.max(0, xp);
    var level = levelFromXp(xp);
    var cur = xpForLevel(level);
    var next = xpForLevel(level + 1);
    var span = next - cur;
    var curXp = Math.max(0, xp - cur);
    return { level: level, currentXp: curXp, span: span, pct: span > 0 ? Math.min(1, curXp / span) : 0 };
  }

  // ─── XP sources ─────────────────────────────────────────────────────────
  var SOURCES = [
    { key: 'login',     label: 'Login',            xp: 10, note: 'First open of the day' },
    { key: 'streak',    label: 'Login streak',     xp: 5,  note: 'Streak bonus per day' },
    { key: 'mood',      label: 'Mood check-in',    xp: 5,  note: 'Per mood logged' },
    { key: 'session',   label: 'Session done',     xp: 15, note: 'Per completed session' },
    { key: 'habit',     label: 'Habit on',         xp: 7,  note: 'Per habit toggled on' },
    { key: 'dsa',       label: 'DSA solved',       xp: 20, note: 'Per completed DSA problem' },
    { key: 'journal',   label: 'Journal/thought',  xp: 5,  note: 'Per entry' },
    { key: 'pushups',   label: 'Pushups',          xp: 10, note: 'Per pushup log' },
    { key: 'perfect',   label: 'Perfect day',      xp: 50, note: 'All habits + session + mood' }
  ];

  function todayStr() {
    var d = new Date();
    var m = ('0' + (d.getMonth() + 1)).slice(-2);
    var day = ('0' + d.getDate()).slice(-2);
    return d.getFullYear() + '-' + m + '-' + day;
  }

  function dateStr(d) {
    var m = ('0' + (d.getMonth() + 1)).slice(-2);
    var day = ('0' + d.getDate()).slice(-2);
    return d.getFullYear() + '-' + m + '-' + day;
  }

  // ─── Reads existing categories via bridge (sync) ────────────────────────
  function readEventsAll(cat) {
    var res = V07.readEventsAll(cat);
    return (res && res.events) ? res.events : [];
  }

  function readEventsForDate(cat, date) {
    var res = V07.readEvents(cat, date);
    return (res && res.events) ? res.events : [];
  }

  function countForDate(events, date, predicate) {
    return events.filter(function (e) { return e.date === date && (!predicate || predicate(e)); }).length;
  }

  // ─── Gamify ledger ──────────────────────────────────────────────────────
  function readLedger() {
    return readEventsAll('gamify');
  }

  function ledgerForDate(ledger, date) {
    return ledger.filter(function (e) { return e.date === date; });
  }

  function ledgerHasLogin(ledger, date) {
    return ledgerForDate(ledger, date).some(function (e) { return e.kind === 'login'; });
  }

  // Compute XP breakdown for a date from live data.
  function computeDayBreakdown(date, events) {
    var bd = { login: 0, streak: 0, mood: 0, session: 0, habit: 0, dsa: 0, journal: 0, pushups: 0, perfect: 0 };

    if (ledgerHasLogin(events.ledger, date)) bd.login = 1;

    bd.mood = countForDate(events.mood, date);
    bd.session = countForDate(events.sessions, date, function (e) { return e.type === 'end'; });
    bd.habit = countForDate(events.habits, date, function (e) { return e.on === true; });
    bd.dsa = countForDate(events.dsa, date, function (e) { return e.completed === true || e.completed === 'true'; });
    bd.journal = countForDate(events.journal, date) + countForDate(events.thought, date);
    bd.pushups = countForDate(events.metrics, date, function (e) { return e.pushups != null; });

    // Perfect day: login + at least one mood + at least one completed session +
    // all 5 habits toggled on that day.
    var habitActivities = ['dsa', 'development', 'ssb', 'reading', 'content_creation'];
    var habitsToggled = {};
    events.habits.forEach(function (h) {
      if (h.date === date && habitsToggled[h.activity] !== true && h.on === true) habitsToggled[h.activity] = true;
    });
    var allHabitsOn = habitActivities.every(function (a) { return habitsToggled[a] === true; });
    bd.perfect = (bd.login > 0 && bd.mood > 0 && bd.session > 0 && allHabitsOn) ? 1 : 0;

    return bd;
  }

  function xpFromBreakdown(bd, streakDays) {
    var total = 0;
    if (bd.login > 0) total += SOURCES[0].xp * bd.login;
    if (bd.login > 0 && streakDays > 0) total += SOURCES[1].xp * streakDays;
    total += SOURCES[2].xp * bd.mood;
    total += SOURCES[3].xp * bd.session;
    total += SOURCES[4].xp * bd.habit;
    total += SOURCES[5].xp * bd.dsa;
    total += SOURCES[6].xp * bd.journal;
    total += SOURCES[7].xp * bd.pushups;
    total += SOURCES[8].xp * bd.perfect;
    return total;
  }

  function streakForDate(sortedDates, dateStr2) {
    var count = 0;
    var set = {};
    sortedDates.forEach(function (x) { set[x] = true; });
    var d = new Date(dateStr2 + 'T00:00:00');
    while (set[dateStr(d)]) { count++; d.setDate(d.getDate() - 1); }
    return count;
  }

  // Recompute totals across all "played" days (those with a login record).
  function recomputeAll(events) {
    var ledger = events.ledger;
    var loginDates = ledger.filter(function (e) { return e.kind === 'login'; }).map(function (e) { return e.date; });
    var dates = [];
    loginDates.forEach(function (d) { if (dates.indexOf(d) < 0) dates.push(d); });
    dates.sort();

    var streak = streakForDate(dates, todayStr());

    var totalXp = 0;
    var byDate = {};
    for (var i = 0; i < dates.length; i++) {
      var d = dates[i];
      var bd = computeDayBreakdown(d, events);
      var s = (d === todayStr()) ? streak : streakForDate(dates, d);
      var dayXp = xpFromBreakdown(bd, s);
      byDate[d] = { xp: dayXp, breakdown: bd };
      totalXp += dayXp;
    }
    return { total: totalXp, byDate: byDate, streak: streak, dates: dates };
  }

  // ─── Record login (first open of the day) ───────────────────────────────
  function ensureLogin() {
    var today = todayStr();
    var ledger = readLedger();
    if (!ledgerHasLogin(ledger, today)) {
      V07.writeEvent('gamify', { kind: 'login', date: today, ts: new Date().toISOString() });
    }
  }

  // ─── Shared API for the full page, the widget, and the FAB runner ────────
  window.v07Gamify = {
    today: todayStr,
    stats: function () {
      var events = loadAll();
      var data = recomputeAll(events);
      var today = todayStr();
      data.loggedInToday = ledgerHasLogin(events.ledger, today);
      return {
        level: progressFromXp(data.total).level,
        total: data.total,
        today: data.byDate[today] ? data.byDate[today].xp : 0,
        streak: data.streak,
        loggedInToday: data.loggedInToday
      };
    },
    checkIn: function () {
      var today = todayStr();
      var ledger = readLedger();
      var already = ledgerHasLogin(ledger, today);
      ensureLogin();
      V07.toast(already ? 'Already checked in today (+10 XP)' : 'Checked in +10 XP');
      return !already;
    }
  };

  // FAB quick action (runner mode): expose a function the dashboard can call.
  window.v07QuickAdd = function () {
    v07Gamify.checkIn();
  };

  // ─── Rendering ──────────────────────────────────────────────────────────
  var root = null;

  function el(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt !== undefined) e.textContent = txt;
    return e;
  }

  function render(data) {
    if (!root) root = document.getElementById('gamify-root');
    if (!root) return;
    root.innerHTML = '';

    var today = todayStr();
    var prog = progressFromXp(data.total);

    var header = el('div', 'g-header');
    var lvlRow = el('div', 'g-lvl-row');
    lvlRow.appendChild(el('div', 'g-lvl-badge', 'LVL ' + prog.level));
    lvlRow.appendChild(el('div', 'g-total', data.total.toLocaleString() + ' XP'));
    header.appendChild(lvlRow);

    var bar = el('div', 'g-bar');
    var fill = el('div', 'g-bar-fill');
    fill.style.width = Math.round(prog.pct * 100) + '%';
    bar.appendChild(fill);
    header.appendChild(bar);
    var barLbl = el('div', 'g-bar-lbl', prog.currentXp + ' / ' + prog.span + ' XP to next level');
    header.appendChild(barLbl);

    var stats = el('div', 'g-stats');
    var todayXp = data.byDate[today] ? data.byDate[today].xp : 0;
    stats.appendChild(el('div', 'g-stat g-stat-xp', todayXp + ' XP today'));
    var streakLbl = data.streak > 1 ? data.streak + ' day streak' : (data.streak === 1 ? '1 day streak' : 'No streak yet');
    stats.appendChild(el('div', 'g-stat g-stat-streak', streakLbl));
    header.appendChild(stats);

    root.appendChild(header);

    if (data.loggedInToday) {
      root.appendChild(el('div', 'g-done', 'Logged in today +10 XP'));
    } else {
      var loginBtn = el('button', 'g-btn', 'CHECK IN (+10 XP)');
      loginBtn.onclick = function () { ensureLogin(); boot(); };
      root.appendChild(loginBtn);
    }

    var todayBreakdown = data.byDate[today];
    if (todayBreakdown) {
      root.appendChild(el('div', 'g-sec-title', "TODAY'S XP"));
      var bdList = el('div', 'g-bd-list');
      SOURCES.forEach(function (src) {
        var count = todayBreakdown.breakdown[src.key] || 0;
        if (count <= 0) return;
        var xp = src.xp * count;
        var row = el('div', 'g-bd-row');
        row.appendChild(el('span', 'g-bd-label', src.label + ' x' + count));
        row.appendChild(el('span', 'g-bd-xp', '+' + xp + ' XP'));
        bdList.appendChild(row);
      });
      if (!bdList.children.length) bdList.appendChild(el('div', 'g-bd-empty', 'No XP earned today yet.'));
      root.appendChild(bdList);
    }

    var recent = data.dates.slice().sort().reverse().slice(0, 7);
    if (recent.length) {
      root.appendChild(el('div', 'g-sec-title', 'RECENT DAYS'));
      var hist = el('div', 'g-hist');
      recent.forEach(function (d) {
        var entry = data.byDate[d];
        var row = el('div', 'g-hist-row');
        row.appendChild(el('span', 'g-hist-date', d));
        row.appendChild(el('span', 'g-hist-xp', (entry ? entry.xp : 0) + ' XP'));
        hist.appendChild(row);
      });
      root.appendChild(hist);
    }
  }

  function loadAll() {
    return {
      ledger: readLedger(),
      mood: readEventsAll('mood'),
      sessions: readEventsAll('sessions'),
      habits: readEventsAll('habits'),
      dsa: readEventsAll('dsa'),
      journal: readEventsAll('journal'),
      thought: readEventsAll('thought'),
      metrics: readEventsAll('metrics')
    };
  }

  function boot() {
    var events = loadAll();
    var data = recomputeAll(events);
    data.loggedInToday = ledgerHasLogin(events.ledger, todayStr());
    render(data);
    ensureLogin();
    var events2 = loadAll();
    var data2 = recomputeAll(events2);
    data2.loggedInToday = ledgerHasLogin(events2.ledger, todayStr());
    render(data2);
  }

  // Full-page UI only: skip in runner FAB mode, and skip when no #gamify-root
  // (e.g. the compact widget loads this file just for the shared API).
  function tryBoot() {
    if (V07.mode === 'runner') return;
    if (!document.getElementById('gamify-root')) return;
    boot();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryBoot);
  } else {
    tryBoot();
  }
})();