// Habits plugin — daily habit tracking on a calendar heatmap.
// Data lives in its own 'hbt' event category:
//   kind:'def'  -> single meta event holding the habit list [{id,name,color,created}]
//   kind:'log'  -> one event per (habit, date): {habit:id, on:true/false, date}
// The same file powers the full page, the home widget, and the FAB runner.

(function () {
  var CAT = 'hbt';
  var ACCENT = '#FFB454';
  var PALETTE = ['#FFB454', '#68A6FF', '#4DE086', '#F4D35E', '#FF6F61', '#C792EA', '#FF9F45', '#63D1F4'];

  // ─── Date helpers ────────────────────────────────────────────────────────
  function pad(n) { return ('0' + n).slice(-2); }
  function todayStr() {
    var d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function dateStr(d) {
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function parseDate(s) { return new Date(s + 'T00:00:00'); }
  function addDays(d, n) { var x = new Date(d.getTime()); x.setDate(x.getDate() + n); return x; }
  function mondayBefore(d) { return addDays(parseDate(dateStr(d)), -((parseDate(dateStr(d)).getDay() + 6) % 7)); }

  // ─── Bridge access ───────────────────────────────────────────────────────
  function readAll() {
    var r = V07.readEventsAll(CAT);
    return (r && r.events) ? r.events : [];
  }
  function writeEvent(data) { return V07.writeEvent(CAT, data); }
  function updateEvent(id, fields) { return V07.updateEvent(CAT, id, fields); }

  function findDefEvent(events) {
    var defs = events.filter(function (e) { return e.kind === 'def'; });
    if (!defs.length) return null;
    return defs.sort(function (a, b) { return (a.ts || '').localeCompare(b.ts || ''); }).pop();
  }

  // ─── State ───────────────────────────────────────────────────────────────
  var _defId = null;
  var _habits = [];
  var _logs = [];
  var _loaded = false;

  function loadState() {
    _loaded = false;
    var events = readAll();
    var def = findDefEvent(events);
    _defId = def ? def.id : null;
    _habits = def && Array.isArray(def.habits) ? def.habits : [];
    var ids = {};
    _habits.forEach(function (h) { ids[h.id] = true; });
    _logs = events.filter(function (e) { return e.kind === 'log' && ids[e.habit]; });
    _loaded = true;
  }

  function saveDefs() {
    if (_defId) {
      updateEvent(_defId, { habits: _habits, date: todayStr() });
    } else {
      writeEvent({ kind: 'def', habits: _habits, date: todayStr(), ts: new Date().toISOString() });
      var def = findDefEvent(readAll());
      _defId = def ? def.id : null;
    }
  }

  function logFor(habitId, date) {
    for (var i = 0; i < _logs.length; i++) {
      if (_logs[i].habit === habitId && _logs[i].date === date) return _logs[i];
    }
    return null;
  }

  function setOnForDate(habitId, date, on) {
    if (!_loaded) loadState();
    var e = logFor(habitId, date);
    if (e) {
      if (e.on !== on) updateEvent(e.id, { on: on, date: date });
    } else if (on) {
      writeEvent({ kind: 'log', habit: habitId, date: date, on: true, ts: new Date().toISOString() });
    }
    loadState();
  }

  // ─── Aggregates ──────────────────────────────────────────────────────────
  function countsByDate() {
    var per = {};
    _logs.forEach(function (e) {
      if (e.on && e.date && e.habit) {
        if (!per[e.date]) per[e.date] = {};
        per[e.date][e.habit] = true;
      }
    });
    var out = {};
    Object.keys(per).forEach(function (k) { out[k] = Object.keys(per[k]).length; });
    return out;
  }

  function isPerfect(counts, date) {
    return _habits.length > 0 && (counts[date] || 0) >= _habits.length;
  }

  function currentStreak() {
    var counts = countsByDate();
    var d = todayStr();
    if (!isPerfect(counts, d)) d = dateStr(addDays(parseDate(d), -1));
    var s = 0;
    while (isPerfect(counts, d)) { s++; d = dateStr(addDays(parseDate(d), -1)); }
    return s;
  }

  function bestStreak() {
    var counts = countsByDate();
    var perfect = {};
    Object.keys(counts).forEach(function (k) { if (isPerfect(counts, k)) perfect[k] = true; });
    var dates = Object.keys(perfect).sort();
    var best = 0, run = 0, prev = null;
    dates.forEach(function (k) {
      var prevDay = dateStr(addDays(parseDate(k), -1));
      run = (prev && prev === prevDay) ? run + 1 : 1;
      if (run > best) best = run;
      prev = k;
    });
    return best;
  }

  // ─── Mutations ───────────────────────────────────────────────────────────
  function addHabit(name) {
    if (!name || !name.trim()) return false;
    if (!_loaded) loadState();
    _habits.push({
      id: 'h' + Date.now().toString(36),
      name: name.trim(),
      color: PALETTE[_habits.length % PALETTE.length],
      created: todayStr()
    });
    saveDefs();
    return true;
  }

  function removeHabit(id) {
    if (!_loaded) loadState();
    _habits = _habits.filter(function (h) { return h.id !== id; });
    saveDefs();
  }

  function logAll() {
    if (!_loaded) loadState();
    if (!_habits.length) { V07.toast('No habits yet — open HABITS to add'); return false; }
    _habits.forEach(function (h) { setOnForDate(h.id, todayStr(), true); });
    V07.toast('All habits logged (' + _habits.length + ' today)');
    return true;
  }

  // ─── Heatmap grid data ───────────────────────────────────────────────────
  // Returns cols (weeks) of 7 cells each (Mon..Sun), ending at today's week.
  function buildHeatmap(weeks) {
    var counts = countsByDate();
    var today = todayStr();
    var start = mondayBefore(addDays(parseDate(today), -(weeks - 1) * 7));
    var cols = [];
    for (var i = 0; i < weeks; i++) {
      var col = [];
      for (var r = 0; r < 7; r++) {
        var d = addDays(start, i * 7 + r);
        var key = dateStr(d);
        var future = key > today;
        col.push({
          date: key,
          dow: r,
          future: future,
          done: future ? 0 : (counts[key] || 0),
          total: _habits.length,
          complete: future ? 0 : (counts[key] || 0) / Math.max(1, _habits.length)
        });
      }
      cols.push(col);
    }
    // month labels: which column starts a new month
    var labels = [];
    var prevLabel = '';
    for (var c = 0; c < weeks; c++) {
      var m = cols[c][0].date.slice(5, 7);
      var names = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      var lbl = names[parseInt(m, 10)] || '';
      if (lbl && lbl !== prevLabel) labels.push({ col: c, label: lbl });
      prevLabel = lbl || prevLabel;
    }
    return { cols: cols, labels: labels, today: today };
  }

  function intensityColor(complete, done) {
    if (done <= 0) return 'transparent';
    var a = complete >= 1 ? 0.95 : complete >= 0.6 ? 0.65 : complete >= 0.3 ? 0.45 : 0.28;
    return 'rgba(255,180,84,' + a + ')';
  }

  // Shared renderer: builds the grid inside `container`.
  // opts: {weeks, cell, gap, labels(bool), interactive(bool, clickCell(date))}
  function renderHeatmap(container, opts) {
    container.innerHTML = '';
    var grid = buildHeatmap(opts.weeks);
    var cell = (opts && opts.cell) || 12;
    var gap = (opts && opts.gap) || 3;
    var colW = cell + gap;

    var wrap = document.createElement('div');
    wrap.style.cssText = 'display:flex;flex-direction:column;gap:4px';

    // month labels row
    var head = document.createElement('div');
    head.style.cssText = 'display:flex;width:' + (40 + grid.cols.length * colW) + 'px';
    var spacer = document.createElement('span');
    spacer.style.cssText = 'width:40px;flex-shrink:0';
    head.appendChild(spacer);
    var headCols = document.createElement('span');
    headCols.style.cssText = 'position:relative;display:block;height:12px;flex:1';
    grid.labels.forEach(function (lbl) {
      var s = document.createElement('span');
      s.textContent = lbl.label;
      s.style.cssText = 'position:absolute;left:' + (lbl.col * colW) + 'px;font-family:Space Mono,monospace;font-size:8px;color:var(--muted,#717171);letter-spacing:0.05em';
      headCols.appendChild(s);
    });
    head.appendChild(headCols);
    wrap.appendChild(head);

    // body: label gutter + week columns
    var body = document.createElement('div');
    body.style.cssText = 'display:flex;width:' + (40 + grid.cols.length * colW) + 'px';
    var gutter = document.createElement('div');
    gutter.style.cssText = 'width:40px;flex-shrink:0;display:flex;flex-direction:column';
    ['M', '', 'W', '', 'F', '', ''].forEach(function (l) {
      var g = document.createElement('span');
      g.textContent = l;
      g.style.cssText = 'height:' + cell + 'px;margin-bottom:' + gap + 'px;font-family:Space Mono,monospace;font-size:8px;color:var(--muted,#717171);line-height:' + cell + 'px';
      gutter.appendChild(g);
    });
    body.appendChild(gutter);

    grid.cols.forEach(function (col, ci) {
      var c = document.createElement('div');
      c.style.cssText = 'display:flex;flex-direction:column';
      col.forEach(function (cl) {
        var b = document.createElement('div');
        b.style.cssText = 'width:' + cell + 'px;height:' + cell + 'px;border-radius:2px;margin-bottom:' + gap + 'px;background:' + (cl.future ? 'transparent' : (cl.done > 0 ? intensityColor(cl.complete, cl.done) : 'var(--surface-low,#16181d)')) + ';border:1px solid ' + (cl.future ? 'transparent' : 'rgba(255,180,84,0.14)');
        if (cl.date === grid.today) {
          b.style.boxShadow = '0 0 0 2px #FFB454';
          b.style.borderRadius = '3px';
        }
        if (opts.interactive && !cl.future) {
          b.style.cursor = 'pointer';
          b.title = cl.date + ' — ' + cl.done + '/' + cl.total;
          (function (k) {
            b.onclick = function () { opts.clickCell(k); };
          })(cl.date);
        }
        c.appendChild(b);
      });
      if (ci < grid.cols.length - 1) c.style.marginRight = gap + 'px';
      body.appendChild(c);
    });
    wrap.appendChild(body);
    container.appendChild(wrap);
    data.currentGrid = grid;
  }

  var data = { currentGrid: null };

  // ─── Shared API ──────────────────────────────────────────────────────────
  window.v07Habits = {
    today: todayStr,
    reload: loadState,
    habits: function () { loadState(); return _habits.slice(); },
    stats: function () {
      loadState();
      var counts = countsByDate();
      var t = todayStr();
      return {
        habits: _habits.length,
        todayDone: counts[t] || 0,
        todayTotal: _habits.length,
        current: currentStreak(),
        best: bestStreak(),
        logs: _logs.length
      };
    },
    setOn: function (habitId, on) { setOnForDate(habitId, todayStr(), !!on); },
    setOnForDate: setOnForDate,
    addHabit: addHabit,
    removeHabit: removeHabit,
    logAll: logAll,
    heatmap: buildHeatmap,
    renderHeatmap: renderHeatmap,
    accent: ACCENT
  };

  // FAB quick action (runner mode): dashboard calls this function.
  window.v07LogAll = function () { v07Habits.logAll(); };

  // ─── Full-page UI ────────────────────────────────────────────────────────
  var root = null;
  var _selDate = null;

  function el(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt !== undefined) e.textContent = txt;
    return e;
  }

  function render() {
    if (!root) root = document.getElementById('hbt-root');
    if (!root) return;
    var s = v07Habits.stats();
    var today = todayStr();
    if (!_selDate) _selDate = today;
    root.innerHTML = '';

    // header
    var header = el('div', 'h-header');
    header.appendChild(el('div', 'h-title', 'HABITS'));
    var chips = el('div', 'h-chips');
    var chipCur = el('span', 'h-chip', 'STREAK ' + s.current);
    var chipBest = el('span', 'h-chip h-chip-dim', 'BEST ' + s.best);
    var chipLogs = el('span', 'h-chip h-chip-dim', s.logs + ' LOGS');
    chips.appendChild(chipCur); chips.appendChild(chipBest); chips.appendChild(chipLogs);
    header.appendChild(chips);
    root.appendChild(header);

    // today panel
    var todayBox = el('div', 'h-card');
    var todayRow = el('div', 'h-today-row');
    var tLbl = el('div', 'h-today-lbl', 'TODAY  ' + s.todayDone + ' / ' + s.todayTotal + ' habits');
    todayRow.appendChild(tLbl);
    var logAllBtn = el('button', 'h-btn h-btn-accent', 'LOG ALL');
    logAllBtn.onclick = function () { v07Habits.logAll(); render(); };
    todayRow.appendChild(logAllBtn);
    todayBox.appendChild(todayRow);
    if (s.habits) {
      var list = el('div', 'h-habit-row-list');
      var hb = v07Habits.habits();
      hb.forEach(function (h) {
        list.appendChild(habitToggleRow(h, today, true));
      });
      if (!hb.length) list.appendChild(el('div', 'h-empty', 'No habits yet — add one below.'));
      todayBox.appendChild(list);
    }
    root.appendChild(todayBox);

    // heatmap
    var hmCard = el('div', 'h-card');
    hmCard.appendChild(el('div', 'h-sec', 'CONSISTENCY // LAST 26 WEEKS'));
    var hm = el('div', 'h-heatmap');
    renderHeatmap(hm, { weeks: 26, cell: 12, gap: 3, interactive: true, clickCell: function (d) { _selDate = d; render(); } });
    hmCard.appendChild(hm);
    var legend = el('div', 'h-legend');
    legend.appendChild(el('span', 'h-lg-label', 'LESS'));
    [0, 0.28, 0.45, 0.65, 0.95].forEach(function (a) {
      var s2 = el('span', 'h-lg-cell', '');
      s2.style.background = a <= 0 ? 'var(--surface-low,#16181d)' : 'rgba(255,180,84,' + a + ')';
      legend.appendChild(s2);
    });
    legend.appendChild(el('span', 'h-lg-label', 'MORE'));
    hmCard.appendChild(legend);
    root.appendChild(hmCard);

    // selected day detail
    var det = el('div', 'h-card');
    var dLbl = _selDate === today ? 'TODAY ' + today : _selDate;
    det.appendChild(el('div', 'h-sec', dLbl));
    var dCounts = {};
    var logs = _loaded ? _logs : [];
    logs.forEach(function (e) { if (e.date === _selDate && e.on) dCounts[e.habit] = true; });
    if (v07Habits.habits().length) {
      v07Habits.habits().forEach(function (h) {
        var on = !!dCounts[h.id];
        var r = el('div', 'h-det-row');
        var dot = el('span', 'h-dot', '');
        dot.style.background = h.color;
        r.appendChild(dot);
        r.appendChild(el('span', 'h-det-name', h.name));
        var b = el('button', on ? 'h-btn h-btn-on' : 'h-btn', on ? 'ON' : 'OFF');
        b.onclick = (function (hid, cur) {
          return function () { v07Habits.setOnForDate(hid, _selDate, !cur); loadStateRef(); render(); };
        })(h.id, on);
        r.appendChild(b);
        det.appendChild(r);
      });
    } else {
      det.appendChild(el('div', 'h-empty', 'No habits to track yet.'));
    }
    root.appendChild(det);

    // manage habits
    var mgr = el('div', 'h-card');
    mgr.appendChild(el('div', 'h-sec', 'HABITS'));
    var hbs = v07Habits.habits();
    if (hbs.length) {
      hbs.forEach(function (h) {
        var r = el('div', 'h-mgr-row');
        var dot = el('span', 'h-dot', '');
        dot.style.background = h.color;
        r.appendChild(dot);
        r.appendChild(el('span', 'h-mgr-name', h.name));
        r.appendChild(el('span', 'h-mgr-created', 'since ' + h.created));
        var del = el('span', 'h-del', '\u2715');
        del.title = 'Delete habit';
        del.onclick = function () { if (confirm('Delete "' + h.name + '" and its history?')) { v07Habits.removeHabit(h.id); render(); } };
        r.appendChild(del);
        mgr.appendChild(r);
      });
    } else {
      mgr.appendChild(el('div', 'h-empty', 'No habits yet.'));
    }
    var addRow = el('div', 'h-add-row');
    var input = document.createElement('input');
    input.className = 'h-input';
    input.placeholder = 'New habit name…';
    input.maxLength = 40;
    addRow.appendChild(input);
    var addBtn = el('button', 'h-btn h-btn-accent', 'ADD');
    addBtn.onclick = function () {
      var v = input.value;
      if (v07Habits.addHabit(v)) { V07.toast('Habit added'); render(); }
      else V07.toast('Enter a habit name');
    };
    input.onkeydown = function (ev) { if ((ev.key || ev.keyCode || ev.which) === 'Enter' || (ev.keyCode) === 13) addBtn.onclick(); };
    addRow.appendChild(addBtn);
    mgr.appendChild(addRow);
    root.appendChild(mgr);
  }

  function loadStateRef() { v07Habits.reload(); }

  function habitToggleRow(h, date, forToday) {
    var r = el('div', 'h-habit-row');
    var dot = el('span', 'h-dot', '');
    dot.style.background = h.color;
    r.appendChild(dot);
    r.appendChild(el('span', 'h-habit-name', h.name));
    var on = false;
    _logs.forEach(function (e) { if (e.date === date && e.habit === h.id) on = e.on === true; });
    var b = el('button', on ? 'h-btn h-btn-on' : 'h-btn', on ? 'ON' : 'OFF');
    b.onclick = (function (hid, cur) {
      return function () { v07Habits.setOnForDate(hid, date, !cur); loadStateRef(); render(); };
    })(h.id, on);
    r.appendChild(b);
    return r;
  }

  function boot() {
    loadState();
    render();
  }

  function tryBoot() {
    if (V07.mode === 'runner') return;
    if (!document.getElementById('hbt-root')) return;
    boot();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryBoot);
  } else {
    tryBoot();
  }
})();